const formEscalar = document.getElementById("form-escalar");
const formRemover = document.getElementById("form-remover");
const jogadoresCampo = document.getElementById("jogadores-campo");
const listaJogadores = document.getElementById("lista-jogadores");

const posicoes = {
  goleiro: { x: 50, y: 90 },
  "zagueiro-esquerdo": { x: 20, y: 70 },
  "zagueiro-direito": { x: 80, y: 70 },
  "lateral-esquerdo": { x: 10, y: 50 },
  "lateral-direito": { x: 90, y: 50 },
  "volante": { x: 50, y: 60 },
  "meio-campo": { x: 50, y: 40 },
  "atacante-esquerdo": { x: 30, y: 20 },
  "atacante-direito": { x: 70, y: 20 },
  "centroavante": { x: 50, y: 22 }
};

const jogadores = [];

formEscalar.addEventListener("submit", (e) => {
  e.preventDefault();

  const posicao = document.getElementById("posicao").value;
  const nome = document.getElementById("nome").value;
  const numero = document.getElementById("numero").value;

  if (!posicao || !nome || !numero) return alert("Preencha todos os campos!");

  const jogador = { posicao, nome, numero };

  if (jogadores.some((j) => j.posicao === posicao)) {
    return alert("Já existe um jogador nesta posição!");
  }

  jogadores.push(jogador);

  atualizarCampo();
  atualizarLista();
  formEscalar.reset();
});

formRemover.addEventListener("submit", (e) => {
  e.preventDefault();

  const numero = document.getElementById("numero-remover").value;
  const index = jogadores.findIndex((j) => j.numero === numero);

  if (index === -1) return alert("Jogador não encontrado!");

  jogadores.splice(index, 1);

  atualizarCampo();
  atualizarLista();
  formRemover.reset();
});

function atualizarCampo() {
  jogadoresCampo.innerHTML = "";
  jogadores.forEach((jogador) => {
    const pos = posicoes[jogador.posicao];
    const jogadorDiv = document.createElement("div");
    jogadorDiv.className = "jogador";
    jogadorDiv.style.left = `${pos.x}%`;
    jogadorDiv.style.top = `${pos.y}%`;
    jogadorDiv.innerText = `${jogador.nome} (${jogador.numero})`;
    jogadoresCampo.appendChild(jogadorDiv);
  });
}

function atualizarLista() {
  listaJogadores.innerHTML = "";
  jogadores.forEach((jogador) => {
    const li = document.createElement("li");
    li.innerText = `${jogador.nome} - ${jogador.posicao} - ${jogador.numero}`;
    listaJogadores.appendChild(li);
  });
}
